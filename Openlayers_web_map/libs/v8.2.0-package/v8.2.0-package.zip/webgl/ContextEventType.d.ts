declare namespace _default {
    let LOST: string;
    let RESTORED: string;
}
export default _default;
//# sourceMappingURL=ContextEventType.d.ts.map